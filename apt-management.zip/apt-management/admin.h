#ifndef ADMIN_H
#define ADMIN_H
#include <iostream>

void admin();

#endif // ADMIN_H
