#ifndef USER_H
#define USER_H

void user();

#endif // USER_H
